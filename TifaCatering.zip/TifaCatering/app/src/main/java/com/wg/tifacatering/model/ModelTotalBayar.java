package com.wg.tifacatering.model;

public class ModelTotalBayar {
    public int getTotalBayar() {
        return totalBayar;
    }

    public ModelTotalBayar(int totalBayar) {
        this.totalBayar = totalBayar;
    }

    private int totalBayar;

}
