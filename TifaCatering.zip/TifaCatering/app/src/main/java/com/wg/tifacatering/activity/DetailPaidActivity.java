package com.wg.tifacatering.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.wg.tifacatering.R;

public class DetailPaidActivity extends AppCompatActivity {

    public static final String KEY_HISTORY = "ffdhwasefa";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_paid);
    }
}
